﻿namespace LoanReviewApi.Common
{
    public class Class1
    {

    }
}
